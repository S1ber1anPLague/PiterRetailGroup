﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace PiterRetailGroup
{
    public partial class Info : Form
    {
        public Info()
        {
            InitializeComponent();
        }

        private void EditButton_Click(object sender, EventArgs e)
        {
            Price92.ReadOnly = false;
            Amount92.ReadOnly = false;
            Price95.ReadOnly = false;
            Amount95.ReadOnly = false;
            Price98.ReadOnly = false;
            Amount98.ReadOnly = false;
            PriceDT.ReadOnly = false;
            AmountDT.ReadOnly = false;
            SaveButton.Visible = true;
            EditButton.Visible = false;
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            Price92.ReadOnly = true;
            Amount92.ReadOnly = true;
            Price95.ReadOnly = true;
            Amount95.ReadOnly = true;
            Price98.ReadOnly = true;
            Amount98.ReadOnly = true;
            PriceDT.ReadOnly = true;
            AmountDT.ReadOnly = true;
            SaveButton.Visible = false;
            EditButton.Visible = true;
        }

        private void GoBackButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
