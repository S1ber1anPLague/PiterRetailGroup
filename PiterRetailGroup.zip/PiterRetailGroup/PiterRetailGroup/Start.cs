﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace PiterRetailGroup
{
    public partial class Start : Form
    {
        public Start()
        {
            InitializeComponent();

        }


        private void Go_Click(object sender, EventArgs e)
        {
            
        
              
            if (Number.Text != String.Empty)
            {
                Info info = new Info();
                info.Show();
            }
            else
            {
                MessageBox.Show("Вы не ввели номер АЗС!");
            }


        }
    }
}
