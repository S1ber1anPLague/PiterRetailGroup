﻿
namespace PiterRetailGroup
{
    partial class Info
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.Address = new System.Windows.Forms.TextBox();
            this.Price98 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Amount95 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Price95 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.Amount92 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.Price92 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.Amount98 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.PriceDT = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.AmountDT = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.EditButton = new System.Windows.Forms.Button();
            this.GoBackButton = new System.Windows.Forms.Button();
            this.SaveButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Адрес АЗС";
            // 
            // Address
            // 
            this.Address.Location = new System.Drawing.Point(195, 10);
            this.Address.Name = "Address";
            this.Address.ReadOnly = true;
            this.Address.Size = new System.Drawing.Size(183, 23);
            this.Address.TabIndex = 1;
            // 
            // Price98
            // 
            this.Price98.Location = new System.Drawing.Point(195, 155);
            this.Price98.Name = "Price98";
            this.Price98.ReadOnly = true;
            this.Price98.Size = new System.Drawing.Size(183, 23);
            this.Price98.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 155);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(107, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "Цена литра АИ-98";
            // 
            // Amount95
            // 
            this.Amount95.Location = new System.Drawing.Point(195, 126);
            this.Amount95.Name = "Amount95";
            this.Amount95.ReadOnly = true;
            this.Amount95.Size = new System.Drawing.Size(183, 23);
            this.Amount95.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 126);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(163, 15);
            this.label3.TabIndex = 4;
            this.label3.Text = "Остаток АИ-95 в хранилище";
            // 
            // Price95
            // 
            this.Price95.Location = new System.Drawing.Point(195, 97);
            this.Price95.Name = "Price95";
            this.Price95.ReadOnly = true;
            this.Price95.Size = new System.Drawing.Size(183, 23);
            this.Price95.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 97);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(107, 15);
            this.label4.TabIndex = 6;
            this.label4.Text = "Цена литра АИ-95";
            // 
            // Amount92
            // 
            this.Amount92.Location = new System.Drawing.Point(195, 68);
            this.Amount92.Name = "Amount92";
            this.Amount92.ReadOnly = true;
            this.Amount92.Size = new System.Drawing.Size(183, 23);
            this.Amount92.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(13, 68);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(166, 15);
            this.label5.TabIndex = 8;
            this.label5.Text = "Остаток  АИ-92 в хранилище";
            // 
            // Price92
            // 
            this.Price92.Location = new System.Drawing.Point(195, 39);
            this.Price92.Name = "Price92";
            this.Price92.ReadOnly = true;
            this.Price92.Size = new System.Drawing.Size(183, 23);
            this.Price92.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(13, 39);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(107, 15);
            this.label6.TabIndex = 10;
            this.label6.Text = "Цена литра АИ-92";
            // 
            // Amount98
            // 
            this.Amount98.Location = new System.Drawing.Point(195, 184);
            this.Amount98.Name = "Amount98";
            this.Amount98.ReadOnly = true;
            this.Amount98.Size = new System.Drawing.Size(183, 23);
            this.Amount98.TabIndex = 13;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(13, 184);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(163, 15);
            this.label7.TabIndex = 12;
            this.label7.Text = "Остаток АИ-98 в хранилище";
            // 
            // PriceDT
            // 
            this.PriceDT.Location = new System.Drawing.Point(195, 213);
            this.PriceDT.Name = "PriceDT";
            this.PriceDT.ReadOnly = true;
            this.PriceDT.Size = new System.Drawing.Size(183, 23);
            this.PriceDT.TabIndex = 15;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(13, 213);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(88, 15);
            this.label8.TabIndex = 14;
            this.label8.Text = "Цена литра ДТ";
            // 
            // AmountDT
            // 
            this.AmountDT.Location = new System.Drawing.Point(195, 242);
            this.AmountDT.Name = "AmountDT";
            this.AmountDT.ReadOnly = true;
            this.AmountDT.Size = new System.Drawing.Size(183, 23);
            this.AmountDT.TabIndex = 17;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(13, 242);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(144, 15);
            this.label9.TabIndex = 16;
            this.label9.Text = "Остаток ДТ в хранилище";
            // 
            // EditButton
            // 
            this.EditButton.Location = new System.Drawing.Point(195, 283);
            this.EditButton.Name = "EditButton";
            this.EditButton.Size = new System.Drawing.Size(183, 44);
            this.EditButton.TabIndex = 18;
            this.EditButton.Text = "Редактировать ";
            this.EditButton.UseVisualStyleBackColor = true;
            this.EditButton.Click += new System.EventHandler(this.EditButton_Click);
            // 
            // GoBackButton
            // 
            this.GoBackButton.Location = new System.Drawing.Point(488, 2);
            this.GoBackButton.Name = "GoBackButton";
            this.GoBackButton.Size = new System.Drawing.Size(75, 31);
            this.GoBackButton.TabIndex = 19;
            this.GoBackButton.Text = "<<";
            this.GoBackButton.UseVisualStyleBackColor = true;
            this.GoBackButton.Click += new System.EventHandler(this.GoBackButton_Click);
            // 
            // SaveButton
            // 
            this.SaveButton.Location = new System.Drawing.Point(415, 283);
            this.SaveButton.Name = "SaveButton";
            this.SaveButton.Size = new System.Drawing.Size(139, 44);
            this.SaveButton.TabIndex = 20;
            this.SaveButton.Text = "Сохранить";
            this.SaveButton.UseVisualStyleBackColor = true;
            this.SaveButton.Visible = false;
            this.SaveButton.Click += new System.EventHandler(this.SaveButton_Click);
            // 
            // Info
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(566, 339);
            this.Controls.Add(this.SaveButton);
            this.Controls.Add(this.GoBackButton);
            this.Controls.Add(this.EditButton);
            this.Controls.Add(this.AmountDT);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.PriceDT);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.Amount98);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.Price92);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.Amount92);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Price95);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Amount95);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Price98);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Address);
            this.Controls.Add(this.label1);
            this.Name = "Info";
            this.Text = "Управление АЗС №";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Address;
        private System.Windows.Forms.TextBox Price98;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Amount95;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox Price95;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox Amount92;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox Price92;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox Amount98;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox PriceDT;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox AmountDT;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button EditButton;
        private System.Windows.Forms.Button GoBackButton;
        private System.Windows.Forms.Button SaveButton;
    }
}