﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Media;
using System.Windows.Forms;

namespace PiterRetailGroup
{
    public partial class Camera : Form
    {
        SoundPlayer sp = new SoundPlayer("1.wav.wav");
        public Camera()
        {
            InitializeComponent();
        }

        private void StartButton_Click(object sender, EventArgs e)
        {
            sp.Play();
            NumberBox.Visible = true;
            label1.Visible = true;
            SaveButtton.Visible = true;
            LoadPictureButton.Visible = true;
            picture.Visible = true;
            StartButton.Visible = false;
        }

        private void LoadPictureButton_Click(object sender, EventArgs e)
        {
          
             
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                Bitmap bmp;
                bmp = new Bitmap(openFileDialog1.FileName);                              
                picture.Image = bmp;
                picture.Invalidate();

            }
            
        }

        private void SaveButtton_Click(object sender, EventArgs e)
        {

        }

        private void GoBackButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
