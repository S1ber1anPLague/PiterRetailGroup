﻿
namespace PiterRetailGroup
{
    partial class Camera
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.StartButton = new System.Windows.Forms.Button();
            this.SaveButtton = new System.Windows.Forms.Button();
            this.picture = new System.Windows.Forms.PictureBox();
            this.NumberBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.LoadPictureButton = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.GoBackButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.picture)).BeginInit();
            this.SuspendLayout();
            // 
            // StartButton
            // 
            this.StartButton.Location = new System.Drawing.Point(228, 280);
            this.StartButton.Name = "StartButton";
            this.StartButton.Size = new System.Drawing.Size(192, 30);
            this.StartButton.TabIndex = 0;
            this.StartButton.Text = "Моделирование ситуации";
            this.StartButton.UseVisualStyleBackColor = true;
            this.StartButton.Click += new System.EventHandler(this.StartButton_Click);
            // 
            // SaveButtton
            // 
            this.SaveButtton.Location = new System.Drawing.Point(502, 3);
            this.SaveButtton.Name = "SaveButtton";
            this.SaveButtton.Size = new System.Drawing.Size(101, 32);
            this.SaveButtton.TabIndex = 1;
            this.SaveButtton.Text = "Сохранить";
            this.SaveButtton.UseVisualStyleBackColor = true;
            this.SaveButtton.Visible = false;
            this.SaveButtton.Click += new System.EventHandler(this.SaveButtton_Click);
            // 
            // picture
            // 
            this.picture.Location = new System.Drawing.Point(25, 41);
            this.picture.Name = "picture";
            this.picture.Size = new System.Drawing.Size(578, 186);
            this.picture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picture.TabIndex = 2;
            this.picture.TabStop = false;
            this.picture.Visible = false;
            // 
            // NumberBox
            // 
            this.NumberBox.Location = new System.Drawing.Point(134, 12);
            this.NumberBox.Name = "NumberBox";
            this.NumberBox.Size = new System.Drawing.Size(223, 23);
            this.NumberBox.TabIndex = 3;
            this.NumberBox.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 15);
            this.label1.TabIndex = 4;
            this.label1.Text = "Введите гос.номер";
            this.label1.Visible = false;
            // 
            // LoadPictureButton
            // 
            this.LoadPictureButton.Location = new System.Drawing.Point(228, 233);
            this.LoadPictureButton.Name = "LoadPictureButton";
            this.LoadPictureButton.Size = new System.Drawing.Size(192, 41);
            this.LoadPictureButton.TabIndex = 5;
            this.LoadPictureButton.Text = "Загрузить фотографию";
            this.LoadPictureButton.UseVisualStyleBackColor = true;
            this.LoadPictureButton.Visible = false;
            this.LoadPictureButton.Click += new System.EventHandler(this.LoadPictureButton_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.Filter = "Images|*.bmp;*.png;*.jpg*";
            // 
            // GoBackButton
            // 
            this.GoBackButton.Location = new System.Drawing.Point(624, 3);
            this.GoBackButton.Name = "GoBackButton";
            this.GoBackButton.Size = new System.Drawing.Size(59, 32);
            this.GoBackButton.TabIndex = 6;
            this.GoBackButton.Text = "<<";
            this.GoBackButton.UseVisualStyleBackColor = true;
            this.GoBackButton.Click += new System.EventHandler(this.GoBackButton_Click);
            // 
            // Camera
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(685, 328);
            this.Controls.Add(this.GoBackButton);
            this.Controls.Add(this.LoadPictureButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.NumberBox);
            this.Controls.Add(this.picture);
            this.Controls.Add(this.SaveButtton);
            this.Controls.Add(this.StartButton);
            this.Name = "Camera";
            this.Text = "Camera";
            ((System.ComponentModel.ISupportInitialize)(this.picture)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button StartButton;
        private System.Windows.Forms.Button SaveButtton;
        private System.Windows.Forms.PictureBox picture;
        private System.Windows.Forms.TextBox NumberBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button LoadPictureButton;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button GoBackButton;
    }
}